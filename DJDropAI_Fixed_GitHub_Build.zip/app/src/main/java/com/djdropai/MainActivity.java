package com.djdropai;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText script; Spinner voice; TextView status; TextToSpeech tts;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        script=findViewById(R.id.script); voice=findViewById(R.id.voice); status=findViewById(R.id.status);
        String[] voices={"Deep Voice (demo)","Hype Voice (demo)","Radio Voice (demo)","Female Voice (demo)"};
        voice.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, voices));
        tts=new TextToSpeech(this, s -> { if(s==TextToSpeech.SUCCESS) status.setText("Ready — demo voice available"); });
        findViewById(R.id.generate).setOnClickListener(v -> {
            String text=script.getText().toString().trim();
            if(text.isEmpty()){ script.setError("Enter your DJ drop text"); return; }
            status.setText("Generating your DJ drop…");
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DJDROP");
            status.setText("Playing demo. Connect an AI voice API for premium voices.");
        });
    }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
